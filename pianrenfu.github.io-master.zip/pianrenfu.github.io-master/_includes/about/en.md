This is used for fraudulent activities
